package Entity;
public class Laundry{
	private String customerId;
	private String customerName;
	private String customerContact;
	private String serviceType;
	private int numberofLaundryItems;
	
	private static int laundryCounter=0;
	
	public Laundry(){}
	public Laundry(String customerId,String customerName,String customerContact,String serviceType,int numberofLaundryItems){
		this.customerName=customerName;
		this.customerContact=customerContact;
		this.customerId=customerId;
		this.serviceType=serviceType;
		setnumberofLaundryItems(numberofLaundryItems);
		laundryCounter++;
	}
	
	public void setcustomerName(String customerName){
		this.customerName=customerName;
	}
	
	public void setcustomerContact(String customerContact){
		this.customerContact=customerContact;
	}
	
	public void setcustomerId(String customerId){
		this.customerId=customerId;
	}
	
	public void setserviceType(String serviceType){
		this.serviceType=serviceType;
	}
	
	public void setnumberofLaundryItems(int numberofLaundryItems){
		if(numberofLaundryItems>0){
			this.numberofLaundryItems=numberofLaundryItems;
		}
	}

	public String getcustomerId(){return customerId;}
	public String getcustomerName(){return customerName;}
	public String getcustomerContact(){return customerContact;}
	public String getserviceType(){return serviceType;}
	public int getnumberofLaundryItems(){return numberofLaundryItems;}
	
	public void showLaundryInfo(){
		System.out.println("******************************");
		System.out.println(" Customer Id : "+customerId);
		System.out.println(" Customer Name : "+customerName);
		System.out.println(" Customer Contact : "+customerContact);
		System.out.println(" Service Type : "+serviceType);
		System.out.println(" Number of Laundry Items : "+numberofLaundryItems);
		System.out.println("******************************");
	}
	
	
	public String getLaundryAsString(){
		return  "******************************"+"\n"+
			    " Customer Id : "+customerId+"\n"+
				" Customer Name : "+customerName+"\n"+
				" Customer Contact : "+customerContact+"\n"+
				" Service Type : "+serviceType+"\n"+
				" Number of Laundry Items : "+numberofLaundryItems+"\n"+
				"******************************"+"\n";
	}
	
	
	public void addnumberofLaundryItems(int x){
		if(x>0){
			numberofLaundryItems += x;
		}
	}
	
	public static void totalNumberOfUniqueLaundry(){
		System.out.println("Total Number Of Unique Laundry : " + laundryCounter);
	}
	
}