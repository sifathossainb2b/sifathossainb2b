package GUI;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import File.*;

public class LoginPage extends JFrame implements ActionListener{
	JTextField nameTextField;
	JPasswordField passField;
	
	JButton loginButton,registerButton;
	
	Font font = new Font("Cambria",Font.BOLD,20);
	
	public LoginPage(){
		super("Login page");
		super.setSize(400,250);
		super.setLocation (550,250);
		super.setDefaultCloseOperation(EXIT_ON_CLOSE);
		super.setLayout(null);
		super.getContentPane().setBackground(new Color(241, 148, 138));
		
		JLabel nameLabel = new JLabel("User Name");
		nameLabel.setFont(font);
		nameLabel.setBounds(10,10,150,30);
		this.add(nameLabel);
		
		nameTextField = new JTextField();
		nameTextField.setFont(font);
		nameTextField.setBounds(10+150,10,200,30);
		this.add(nameTextField);
		
		JLabel passLabel = new JLabel("Password");
		passLabel.setFont(font);
		passLabel.setBounds(10,10+30,150,50);
		this.add(passLabel);
		
		passField = new JPasswordField();
		passField.setFont(font);
		passField.setBounds(10+150,10+30,200,30);
		passField.setEchoChar('*');
		this.add(passField);
		
		loginButton = new JButton("Login");
		loginButton.setFont(font);
		loginButton.setBounds(10+150,10+30+40,200,30);
		loginButton.addActionListener(this);
		this.add(loginButton);
		
		
		registerButton = new JButton("Register User");
		registerButton.setFont(font);
		registerButton.setBounds(10+150,10+30+40+40,200,30);
		registerButton.addActionListener(this);
		this.add(registerButton);
			
		
		this.setVisible(true);
	}
	

	public void actionPerformed(ActionEvent e){
    if (loginButton == e.getSource()){
        String uname = nameTextField.getText();
        String upass = new String(passField.getPassword());

        if(FileIO.checkUser(uname, upass)){
            JOptionPane.showMessageDialog(this, "Valid User");
            WelcomePage welcomePage = new WelcomePage(uname); 
            this.setVisible(false);
        }
        else{
            JOptionPane.showMessageDialog(this, "Invalid User Name or Password");
        }
    }
    else if(registerButton == e.getSource()){
        RegisterPage register = new RegisterPage();
		}
	}
}