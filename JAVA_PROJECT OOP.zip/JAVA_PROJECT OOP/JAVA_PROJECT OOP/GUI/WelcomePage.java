package GUI;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import File.*;

public class WelcomePage extends JFrame implements ActionListener {
    JButton nextButton;
    JLabel welcomeLabel;
    Font font = new Font("Cambria", Font.BOLD, 20);

    public WelcomePage(String username) {
        super("Welcome Page");
        super.setSize(660, 460);
        super.setLocation(300, 100);
        super.setDefaultCloseOperation(EXIT_ON_CLOSE);
        super.setLayout(null);
        super.getContentPane().setBackground(new Color(173, 216, 230));

        welcomeLabel = new JLabel("Welcome to LaundryRoom!");
        welcomeLabel.setFont(new Font("Cambria", Font.BOLD, 17));
        welcomeLabel.setBounds(100, 40, 220, 30);
        this.add(welcomeLabel);

        ImageIcon i = new ImageIcon(ClassLoader.getSystemResource("GUI/Welcome_page.png")); 
		JLabel image = new JLabel(i);

		setContentPane(new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("GUI/Welcome_page.png"));
                Image img = icon.getImage();
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
            }
        });
		
		nextButton = new JButton("Next");
        nextButton.setFont(font);
        nextButton.setBounds(110, 120, 150, 40);
        nextButton.addActionListener(this);
        this.add(nextButton);

        this.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (nextButton == e.getSource()) {
            LaundryManagementPage laundryPage = new LaundryManagementPage();
            this.setVisible(false);
        }
    }
}
