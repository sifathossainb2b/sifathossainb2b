package GUI;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import Entity.Laundry;
import EntityList.LaundryList;
import File.*;

public class LaundryManagementPage extends JFrame implements ActionListener{
	Font titleFont = new Font("Cambria",Font.BOLD,30);
	Font font15 = new Font("Cambria",Font.BOLD,15);
	
	JTextField idTextField,nameTextField,contactTextField,typeTextField,itemsTextField;
	JTextField searchTextField,deleteTextField;
	
	JButton addButton,updateButton,searchButton,deleteButton,clearButton,showAllButton;
	
	JTextArea textArea;
	
	LaundryList laundryList = new LaundryList(1000);
	
	public LaundryManagementPage(){
		super("Laundry Management Page");
		super.setDefaultCloseOperation(EXIT_ON_CLOSE);
		super.setSize(960,660);
		super.setLocation(300,100);
		super.getContentPane().setBackground(new Color(118, 215, 196));
		super.setLayout(null);
		
		
		JLabel title = new JLabel("LAUNDRY INFO");
		title.setBounds(300,10,320,50);
		title.setFont(new Font("Cambria",Font.BOLD,40));
		this.add(title);
		
		
		int top = 50;
		int gap = 40;
		
		JLabel idLabel = new JLabel("Customer ID");
		idLabel.setBounds(700,top,200,30); 
		idLabel.setFont(font15);
		this.add(idLabel);
		
		idTextField = new JTextField();
		idTextField.setBounds(700,top+=gap,200,30); 
		idTextField.setFont(font15);
		this.add(idTextField);
		
		JLabel nameLabel = new JLabel("Customer Name");
		nameLabel.setBounds(700,top+=gap,200,30); 
		nameLabel.setFont(font15);
		
		nameTextField = new JTextField();
		nameTextField.setBounds(700,top+=gap,200,30); 
		nameTextField.setFont(font15);
		
		JLabel contactLabel = new JLabel("Customer Contact");
		contactLabel.setBounds(700,top+=gap,200,30); 
		contactLabel.setFont(font15);
		
		contactTextField = new JTextField();
		contactTextField.setBounds(700,top+=gap,200,30); 
		contactTextField.setFont(font15);
		
		JLabel typeLabel = new JLabel("Service Type");
		typeLabel.setBounds(700,top+=gap,200,30); 
		typeLabel.setFont(font15);
		
		typeTextField = new JTextField();
		typeTextField.setBounds(700,top+=gap,200,30); 
		typeTextField.setFont(font15);
		
		JLabel itemsLabel = new JLabel("Number of Laundry Items");
		itemsLabel.setBounds(700,top+=gap,200,30); 
		itemsLabel.setFont(font15);
		
		itemsTextField = new JTextField();
		itemsTextField.setBounds(700,top+=gap,200,30);
		itemsTextField.setFont(font15);
		
		addButton = new JButton("ADD");
		addButton.setBounds(700,480,200,30);
		addButton.setBackground(Color.YELLOW);
		addButton.setFont(font15);
		addButton.addActionListener(this);
		
		
		FileIO.loadLaundriesFromFile(laundryList);

		
		textArea = new JTextArea();
		textArea.setBounds(40,25,600,350);
		textArea.setBackground(new Color(236, 240, 241));
		textArea.setFont(new Font("Arial",Font.BOLD,15));
		textArea.setEditable(false);
		textArea.setText(laundryList.getAllAsString());
		
		JScrollPane jsp = new JScrollPane(textArea);
		jsp.setBounds(40,70,600,350);
		this.add(jsp);
		
		
		JLabel searchLabel = new JLabel("Search By Customer ID");
		searchLabel.setBounds(40,450,250,30);
		searchLabel.setFont(font15);
		
		searchTextField = new JTextField();
		searchTextField.setBounds(40,480,200,30);
		searchTextField.setFont(font15);
		
		searchButton = new JButton("SEARCH");
		searchButton.setBounds(250,480,120,30);
		searchButton.setBackground(new Color(218, 123, 147));
		searchButton.setFont(font15);
		searchButton.addActionListener(this);
		
		
		JLabel deleteLabel = new JLabel("Delete By Customer ID");
		deleteLabel.setBounds(40,520,200,30);
		deleteLabel.setFont(font15);
		
		deleteTextField = new JTextField();
		deleteTextField.setBounds(40,550,200,30); 
		deleteTextField.setFont(font15);
		
		deleteButton = new JButton("DELETE");
		deleteButton.setBounds(250,550,120,30); 
		deleteButton.setBackground(Color.RED);
		deleteButton.setFont(font15);
		deleteButton.addActionListener(this);
		
		
		showAllButton = new JButton("SHOW ALL");
		showAllButton.setBounds(700,550,200,30); 
		showAllButton.setBackground(new Color(93, 173, 226));
		showAllButton.setFont(font15);
		showAllButton.addActionListener(this);
		
		
		clearButton = new JButton("CLEAR SCREEN");
		clearButton.setBounds(700,515,200,30); 
		clearButton.setBackground(new Color(179, 182, 183 ));
		clearButton.setFont(font15);
		clearButton.addActionListener(this);
		
		
		
	
		this.add(nameLabel);
		this.add(nameTextField);
		this.add(contactLabel);
		this.add(contactTextField);
		this.add(typeLabel);
		this.add(typeTextField);
		this.add(itemsLabel);
		this.add(itemsTextField);
		this.add(addButton);
		this.add(searchLabel);
		this.add(searchTextField);
		this.add(searchButton);
		this.add(deleteLabel);
		this.add(deleteTextField);
		this.add(deleteButton);
		this.add(clearButton);
		this.add(showAllButton);
		
		super.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e){
		if(addButton == e.getSource()){
			System.out.println("Add Clicked");
			String id = idTextField.getText();
			String name = nameTextField.getText();
			String contact = contactTextField.getText();
			String type = typeTextField.getText();
			int items = Integer.parseInt( itemsTextField.getText() ) ;
			
			Laundry l = laundryList.getById(id);
			if(l == null){
				Laundry newLaundry = new Laundry(id,name,contact,type,items);
				laundryList.insert(newLaundry);
				FileIO.saveLaundry(newLaundry);
				textArea.setText( laundryList.getAllAsString() );
			}
			else{
				JOptionPane.showMessageDialog(this,"Customer ID Already Used","ID ERROR",JOptionPane.WARNING_MESSAGE);
			}
		}
		else if(searchButton == e.getSource()){
			System.out.println("Search Clicked");
			String id = searchTextField.getText();
			Laundry l = laundryList.getById(id);
			if(l!=null){
				textArea.setText( l.getLaundryAsString() );
			}
			else{
				JOptionPane.showMessageDialog(this,"No Customer Found with This Id","Search Status",JOptionPane.ERROR_MESSAGE);
			}	
		}
		else if(deleteButton == e.getSource()){
			System.out.println("Delete Clicked");
			String id = deleteTextField.getText();
			Laundry l = laundryList.getById(id);
			if(l!=null){
				
				int option = JOptionPane.showConfirmDialog(this,"Are you sure to Delete");
				if(option == JOptionPane.YES_OPTION){
					laundryList.removeById(id);
					textArea.setText( laundryList.getAllAsString() );
				}
			}
			else{
				JOptionPane.showMessageDialog(this,"No Customer Found with This Id","Delete Status",JOptionPane.ERROR_MESSAGE);
			}	
		}
		else if(showAllButton == e.getSource()){
			System.out.println("ShowAll Clicked");
			textArea.setText( laundryList.getAllAsString());
		}
		else if(clearButton == e.getSource()){
			System.out.println("Clear Clicked");
			textArea.setText("");
		}
		
	}
	
}