package GUI;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import File.*;

public class RegisterPage extends JFrame implements ActionListener{
	JTextField nameTextField;
	JPasswordField passField;
	
	JButton loginButton;
	
	Font font = new Font("Cambria",Font.BOLD,20);
	
	public RegisterPage(){
		super("Register page");
		super.setSize(400,250);
		super.setLocation(550,250);
		super.setDefaultCloseOperation(EXIT_ON_CLOSE);
		super.setLayout(null);
		
		JLabel nameLabel = new JLabel("User Name");
		nameLabel.setFont(font);
		nameLabel.setBounds(10,10,150,30);
		this.add(nameLabel);
		
		nameTextField = new JTextField();
		nameTextField.setFont(font);
		nameTextField.setBounds(10+150,10,200,30);
		this.add(nameTextField);
		
		JLabel passLabel = new JLabel("Password");
		passLabel.setFont(font);
		passLabel.setBounds(10,10+30,150,50);
		this.add(passLabel);
		
		passField = new JPasswordField();
		passField.setFont(font);
		passField.setBounds(10+150,10+30,200,30);
		passField.setEchoChar('*');
		this.add(passField);
		
		loginButton = new JButton("Register");
		loginButton.setFont(font);
		loginButton.setBounds(10+150,10+30+40,200,30);
		loginButton.addActionListener(this);
		this.add(loginButton);
			
		
		this.setVisible(true);
	}
	

	public void actionPerformed(ActionEvent e){
		if(loginButton == e.getSource()){
			String uname = nameTextField.getText();
			String upass = new String( passField.getPassword() );
			FileIO.addUser(uname,upass);
			JOptionPane.showMessageDialog(this,"New User Registered");
		}
			
	}
}