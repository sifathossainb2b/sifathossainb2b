package GUI;
import javax.swing.ImageIcon; 
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class WelcomePage extends JFrame implements ActionListener{

	JButton Next, back;
	
	WelcomePage(){
		
		
		
		setSize(771, 578);
		setLocation(400,150);
		setVisible(true);
		setLayout(null);
		
		ImageIcon i = new ImageIcon(ClassLoader.getSystemResource("GUI/welcome_png.png")); 
		JLabel image = new JLabel(i);
		
		
		setContentPane(new JPanel() {
            
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("GUI/welcome_png.png"));
                Image img = icon.getImage();
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
            }
        });
		
		
		
		
		
		
		Next = new JButton("Next");
		Next.setBounds(750,270,150,25);
		add(Next);
		Next.setFont(new Font ("Times new Roman",Font.BOLD, 17));
		Next.setForeground(Color.BLACK);
		Next.setBackground(new Color(255,204,0));
		Next.addActionListener(this);
		
		back = new JButton("Back");
		back.setBounds(930,270,150,25);
		add(back);
		back.setForeground(Color.BLACK);
		back.setFont(new Font("Times new Roman", Font.BOLD, 17));
		back.setBackground(new Color(255,204,0));
		back.addActionListener(this);
		
	}
		
		public void actionPerformed(ActionEvent ae)
		
		{
			if (ae.getSource() == Next)
			{
				setVisible(false);
				new LaundryManagementPage();
				
			}
			else if(ae.getSource() == back)
			{
				setVisible(false);
			}  
				
			
		}
		
			
	public static void main(String[]args) {
		
		 new WelcomePage();
		 
		 
		
	}
	

}