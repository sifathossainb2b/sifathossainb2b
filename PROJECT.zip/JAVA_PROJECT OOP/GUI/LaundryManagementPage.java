package GUI;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import Entity.Laundry;
import EntityList.LaundryList;
import File.*;

public class LaundryManagementPage extends JFrame implements ActionListener{
	Font titleFont = new Font("Cambria",Font.BOLD,30);
	Font font15 = new Font("Cambria",Font.BOLD,15);
	
	JTextField idTextField,nameTextField,typeTextField,copyTextField;
	JTextField searchTextField,deleteTextField;
	
	JButton addButton,updateButton,searchButton,deleteButton,clearButton,showAllButton;
	
	JTextArea textArea;
	
	LaundryList laundryList = new LaundryList(1000);
	
	public LaundryManagementPage(){
		super("Laundry Management Page");
		super.setDefaultCloseOperation(EXIT_ON_CLOSE);
		super.setSize(960,660); 
		super.setLocation(300,100); 
		super.setLayout(null);
		super.getContentPane().setBackground(new Color(118,215,196));
		super.setVisible(true);
		
	
		
		
		
		JLabel title = new JLabel("LAUNDRY INFORMATIONS");
		title.setForeground(new Color(44, 53, 50));
		title.setBounds(305,10,500,50); 
		title.setFont(titleFont);
		super.getContentPane().add(title);
		
	
		
		
		int top = 50;
		int gap = 40;
		
			
	
		JLabel idLabel = new JLabel("Customer ID");
		idLabel.setForeground(new Color(44, 53, 50));
		idLabel.setBounds(700,top,200,30); 
		idLabel.setFont(new Font ("Times new Roman",Font.BOLD,16));
		this.add(idLabel);
		
		idTextField = new JTextField();
		idTextField.setBounds(700,top+=gap,200,30); 
		idTextField.setFont(font15);
		this.add(idTextField);
		
	
		
		JLabel nameLabel = new JLabel("Customer Name");
		nameLabel.setForeground(new Color(44, 53, 50));
		nameLabel.setBounds(700,top+=gap,200,30); 
		nameLabel.setFont(new Font ("Times new Roman",Font.BOLD,16));
		
		nameTextField = new JTextField();
		nameTextField.setBounds(700,top+=gap,200,30); 
		nameTextField.setFont(font15);
		
	
	
		
		JLabel typeLabel = new JLabel("Laundry Type");
		typeLabel.setForeground(new Color(44, 53, 50));
		typeLabel.setBounds(700,top+=gap,200,30);
		typeLabel.setFont(font15);
		
		typeTextField = new JTextField();
		typeTextField.setBounds(700,top+=gap,200,30); 
		typeTextField.setFont(new Font ("Times new Roman",Font.BOLD,16));
		
		
		JLabel copyLabel = new JLabel("Laundry Copy");
		copyLabel.setForeground(new Color(44, 53, 50));
		copyLabel.setBounds(700,top+=gap,200,30); 
		copyLabel.setFont(font15);
		
		copyTextField = new JTextField();
		copyTextField.setBounds(700,top+=gap,200,30); 
		copyTextField.setFont(new Font ("Times new Roman",Font.BOLD,16));
		
		
		
		addButton = new JButton("ADD");
		addButton.setBounds(700,top+=gap,200,30); 
		addButton.setBackground(new Color(39, 39, 39));
		addButton.setOpaque(true);
		addButton.setFont(font15);
		addButton.setForeground(Color.WHITE);
		addButton.addActionListener(this);
		
		
		updateButton = new JButton("UPDATE");
		updateButton.setBounds(700,top+=gap,200,30); 
		updateButton.setBackground(new Color(203, 45, 111));
		updateButton.setForeground(Color.BLACK);
		updateButton.setFont(font15);
		updateButton.addActionListener(this);
		updateButton.setVisible(false);
		
		
		FileIO.loadLaundriesFromFile(laundryList);

		textArea = new JTextArea();
		textArea.setBounds(40,70,600,350);
		textArea.setBackground(Color.WHITE);
		textArea.setForeground(new Color(44, 53, 50));
		textArea.setFont(new Font ("Times new Roman",Font.BOLD,17));
		textArea.setEditable(false);
		textArea.setText(laundryList.getAllAsString());
		
		JScrollPane jsp = new JScrollPane(textArea);
		jsp.setBounds(40,70,600,350);
		this.add(jsp);
		
		
		JLabel searchLabel = new JLabel("Search & Delete By Laundry ID");
		searchLabel.setForeground(new Color(44, 53, 50));
		searchLabel.setBounds(40,450,250,30); 
		searchLabel.setFont(new Font ("Times new Roman",Font.BOLD,16));
		
		searchTextField = new JTextField();
		searchTextField.setBounds(40,480,200,30); 
		searchTextField.setFont(font15);
		
		searchButton = new JButton("SEARCH");
		searchButton.setBounds(250,480,120,30); 
		searchButton.setBackground(new Color(116, 116, 116));
		searchButton.setFont(font15);
		searchButton.setForeground(Color.WHITE);
		searchButton.addActionListener(this);
		
		
		
		
		deleteButton = new JButton("DELETE");
		deleteButton.setBounds(60,520,140,30);
		deleteButton.setBackground(new Color(166, 8, 48));
		deleteButton.setForeground(Color.BLACK);
		deleteButton.setFont(font15);
		deleteButton.addActionListener(this);
		
		showAllButton = new JButton("SHOW ALL");
		showAllButton.setBounds(700,480,200,30); 
		showAllButton.setBackground(new Color(204, 204, 204));
		showAllButton.setForeground(Color.BLACK);
		showAllButton.setFont(font15);
		showAllButton.addActionListener(this);
	

	
		clearButton = new JButton("CLEAR SCREEN");
		clearButton.setBounds(700,520,200,30); 
		clearButton.setBackground(Color.DARK_GRAY);
		clearButton.setForeground(Color.WHITE);
		clearButton.setFont(font15);
		clearButton.addActionListener(this);
		
		super.getContentPane().revalidate();
		super.getContentPane().repaint();
		
	
		this.add(nameLabel);
		this.add(nameTextField);
		this.add(typeLabel);
		this.add(typeTextField);
		this.add(copyLabel);
		this.add(copyTextField);
		this.add(addButton);
		this.add(updateButton);
		this.add(searchLabel);
		this.add(searchTextField);
		this.add(searchButton);
		this.add(deleteButton);
		this.add(clearButton);
		this.add(showAllButton);
		
		
		
		super.setVisible(true);

	}
	
	
	public void actionPerformed(ActionEvent e){
		if(addButton == e.getSource()){
			System.out.println("Add Clicked");
			String id = idTextField.getText();
			String name = nameTextField.getText();
			String type = typeTextField.getText();
			int copy = Integer.parseInt( copyTextField.getText() ) ;
			
			Laundry l = laundryList.getById(id);
			if(l == null){
				Laundry newLaundry = new Laundry(id,name,type,copy);
				laundryList.insert(newLaundry);
				FileIO.saveLaundry(newLaundry);
				textArea.setText( laundryList.getAllAsString() );
			}
			else{
				JOptionPane.showMessageDialog(this,"Laundry ID Already Used","ID ERROR",JOptionPane.WARNING_MESSAGE);
			}
		}
		else if(updateButton == e.getSource()){
			System.out.println("Update Clicked");
			
		}
		else if(searchButton == e.getSource()){
			System.out.println("Search Clicked");
			String id = searchTextField.getText();
			Laundry l = laundryList.getById(id);
			if(l!=null){
				textArea.setText( l.getLaundryAsString() );
			}
			else{
				JOptionPane.showMessageDialog(this,"No Customer Found with This Id","Search Status",JOptionPane.ERROR_MESSAGE);
			}
			
			
		}
		else if(deleteButton == e.getSource()){
			System.out.println("Delete Clicked");
			String id = searchTextField.getText();
			Laundry l = laundryList.getById(id);
			if(l!=null){
				
				int option = JOptionPane.showConfirmDialog(this,"Once you Delete,all data will be Lost");
				if(option == JOptionPane.YES_OPTION){
					laundryList.removeById(id);
					textArea.setText( laundryList.getAllAsString() );
				}
			}
			else{
				JOptionPane.showMessageDialog(this,"No Customer Found with This Id","Delete Status",JOptionPane.ERROR_MESSAGE);
			}
			
			
		}
		else if(showAllButton == e.getSource()){
			System.out.println("ShowAll Clicked");
			textArea.setText( laundryList.getAllAsString());
		}
		else if(clearButton == e.getSource()){
			System.out.println("Clear Clicked");
			textArea.setText("");
		}
		
	}
	
}