import java.lang.*;
import Entity.Laundry;
import EntityList.*;
import GUI.*;

public class StartGUI{
	public static void main(String []args){
		LoginPage login = new LoginPage();
	}
}