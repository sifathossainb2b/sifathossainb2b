package EntityList;
import Entity.Laundry;


public class LaundryList{
	Laundry laundries[];
	public LaundryList(){
		laundries = new Laundry[4];
	}
	public LaundryList(int size){
		laundries = new Laundry[size];
	}
	
	public void insert(Laundry l){
		boolean flag = false;
		for(int i=0; i < laundries.length; i++){
			if(laundries[i] == null){
				laundries[i] = l;
				flag = true;
				break;
			}
		}
		
		if(flag){
			System.out.println("Succesfuly Inserted..");
		}
		else{
			System.out.println("Failed to Insert..");
		}
	}
	
	public Laundry getById(String id){
		boolean flag = false;
		Laundry l = null;
		for(int i=0;i<laundries.length;i++){
			if(laundries[i]!=null){
				if(laundries[i].getCustomerId().equals(id)){
					flag = true;
					l = laundries[i];
				}
			}
		}
		
		if(flag){
			System.out.println("Customer Found");
		}
		else{
			System.out.println("No Customer Found With this Id..");
		}
		
		return l;
		
	}
	
	public void removeById(String id){
		boolean flag = false;
		for(int i=0;i<laundries.length;i++){
			if(laundries[i]!=null){
				if(laundries[i].getCustomerId().equals(id)){
					flag = true;
					laundries[i] = null;
				}
			}
		}
		
		if(flag){
			System.out.println("Laundry Removed..");
		}
		else{
			System.out.println("No Customer Found With this Id..");
		}
	}
	
	public void showAll(){
		for(int i=0;i<laundries.length;i++){
			if(laundries[i]!=null){
				laundries[i].showLaundryInfo();
			}
		}
	}
	
	public String getAllAsString(){
		String allLaundries = "";
		for(int i=0;i<laundries.length;i++){
			if(laundries[i]!=null){
				allLaundries += laundries[i].getLaundryAsString();
			}
		}
		return allLaundries;
	}
	
}