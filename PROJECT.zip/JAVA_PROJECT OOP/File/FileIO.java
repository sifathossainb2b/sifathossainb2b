package File;
import java.io.*;
import java.util.Scanner;
import Entity.*;
import EntityList.*;


public class FileIO{
	public static boolean checkUser(String uname, String upass){
		boolean flag = false;
		try{
			Scanner fileSc = new Scanner(new File("G:/JAVA_PROJECT OOP/File/data/users.txt"));
			while(fileSc.hasNextLine()){
				String line = fileSc.nextLine();
				String data[] = line.split(";");
				if(uname.equals(data[0]) && upass.equals(data[1])){
					flag = true;
					break;
				}
			}
			fileSc.close();
		}
		catch(Exception e){
			System.out.println("Cannot Read File1");
		}
		return flag;
	}
	
	public static void addUser(String uname, String upass){
		try{
			FileWriter writer = new FileWriter(new File("G:/JAVA_PROJECT OOP/File/data/users.txt"), true);
			writer.write(uname+";"+upass+"\n");
			writer.flush();
			writer.close();
		}
		catch(Exception e){
			System.out.println("Cannot Read File");
		}
	}
	
	public static void loadLaundriesFromFile(LaundryList laundries){
		try{
			Scanner fileSc = new Scanner(new File("G:/JAVA_PROJECT OOP/File/data/laundries.txt"));
			while(fileSc.hasNextLine()){
				String line = fileSc.nextLine();
				String data[] = line.split(";");
				Laundry l = new Laundry(data[0],data[1],data[2],
								  Integer.parseInt(data[3]));
				laundries.insert(l);
			}
			fileSc.close();
		}
		catch(Exception e){
			System.out.println("Cannot Read File1" + e.getMessage());
			e.printStackTrace();
			
		}
	}
	
	
	public static void saveLaundry(Laundry l){
		try{
			FileWriter writer = new FileWriter(new File("./File/data/laundries.txt"), true);
			String line = l.getCustomerId()+";"+l.getCustomerName()+";"+
						  l.getLaundryType()+";"+
						  l.getLaundryCopy()+"\n";
			
			writer.write(line);
	
			writer.flush();
			writer.close();
		}
		catch(Exception e){
			System.out.println("Cannot Read File");
		}
	}
	
}
