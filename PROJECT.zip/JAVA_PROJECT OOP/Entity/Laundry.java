package Entity;
public class Laundry{
	private String customerId;
	private String customerName;
	private String laundryType;
	private int laundryCopy;
	
	private static int laundryCounter=0;
	
	public Laundry(){}
	public Laundry(String customerId, String customerName, String laundryType,int laundryCopy){
		this.customerName = customerName;
		this.customerId = customerId;
		this.laundryType = laundryType;
		setLaundryCopy(laundryCopy);
		laundryCounter++;
	}
	
	public void setCustomerName(String customerName){
		this.customerName = customerName;
	}
	
	
	public void setCustomerId(String customerId){
		this.customerId = customerId;
	}
	
	public void setLaundryType(String laundryType){
		this.laundryType = laundryType;
	}
	
	public void setLaundryCopy(int laundryCopy){
		if(laundryCopy>0){
			this.laundryCopy = laundryCopy;
		}
	}

	public String getCustomerId(){
		return customerId;
		}
	public String getCustomerName(){
		return customerName;
		}
	public String getLaundryType(){
		return laundryType;
		}
	public int getLaundryCopy(){
		return laundryCopy;
		}
	
	public void showLaundryInfo(){
		System.out.println("-------------------------");
		System.out.println("Customer Id : "+customerId);
		System.out.println("Customer Name : "+customerName);
		System.out.println("Laundry Type : "+laundryType);
		System.out.println("Number of Laundry Copy : "+laundryCopy);
		System.out.println("-------------------------");
	}
	
	
	public String getLaundryAsString(){
		return  "**************************"+"\n"+
				"**************************"+"\n"+
			    " 1. Customer Id : "+customerId+"\n"+
				" 2. CustomerName : "+customerName+"\n"+
				" 3. Laundry Type : "+laundryType+"\n"+
				" 4. Laundry Copy : "+laundryCopy+"\n"+
				"**************************"+"\n"+
				"**************************"+"\n";
	}
	
	
	public void addLaundryCopy(int x){
		if(x>0){
			laundryCopy += x;
		}
	}
	
	public static void totalNumberOfUniqueLaundry(){
		System.out.println("Total Number Of Unique Laundry : " + laundryCounter);
	}
	
}